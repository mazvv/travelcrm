Install

1. install application:
    python setup.py develop
    higly recommend to use virtual installation
2. load dump from travelcrm.sql
3. set your database connection settings in development.ini

Seems thats all, must works :)

